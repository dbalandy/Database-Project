<!DOCTYPE html>
<html lang="en">
<head>
<title>Comment Form</title>
<meta charset="utf-8"> 

<?php
$servername = "localhost";
$username = "id2426085_adminclinic";
$password = "omgomg123";

$db_name = "id2426085_clinictest" ;


// Create connection
$conn = mysqli_connect($servername, $username, $password, $db_name);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
echo "Connected successfully";


?>



<style>
body {background-image: url("clinicbr.jpg");
			background-size: 100%;				;
		background-repeat:no-repeat;}
		
form { 	width:300px;
		margin: 0 auto;
		background-color:#eaeaea;
	   font-family: Arial, sans-serif;
       padding: 10px; }
label { float: left;
	    width: 150px; 
        clear: left;
	    text-align: left; 
	    padding-right: 10px;
	    margin-top: 10px; }
input, textarea { margin-top: 10px; 
                  display: block; } 
#mySubmit { margin-center:auto; }



li {
    display: inline;
}
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}

li {
    float: left;
}

li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover {
    background-color: #111;
}

div.copyright{position: fixed;
    bottom: 0;
    width: 100%;}
</style>
</head>
<body>
<header><center><h1><center>Kwantlen Clinic</center>
</h1></center></header>

<ul>
<li> <a href="index.php">Home</a></li>
 <li> <a href="login.php">Login</a></li>
 <li> <a href="contact1.php">Contact</a></li>
</ul>

<main>
<center><h2>Contact Us<br>
				Or Call us at: 555-555-5555</h2></center>
<form method="post"
action="http://webdevbasics.net/scripts/demo.php">
  <label for="myName">Name:</label>
  <input type="text" name="myName" id="myName"
	required="required" placeholder="your first and last name">
  <label for="myEmail">E-mail:</label>
  <input type="email" name="myEmail" id="myEmail"
	required="required" placeholder="you@yourdomain.com">
  <label for="myComments">Comments:</label>
  <textarea name="myComments" id="myComments" rows="2" cols="20"
				required="required"></textarea>
  <input id="mySubmit" type="submit" value="Submit">
</form>

<br>
<br>
<center><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2610.5424179648026!2d-122.87348468431588!3d49.13332497931544!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x4a47f954c726e0b8!2sKwantlen+Polytechnic+University+Library!5e0!3m2!1sen!2sca!4v1491219505797" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe></center>
</main>
</body>
<footer>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<center><div class="copyright">Copyright &copy; 2017 Kwantlen Clinic</div></center>
</footer> 
</html>