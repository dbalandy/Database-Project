<!DOCTYPE html>
<html lang="en">
<head>
<title>Kwantlen Clinic</title>
<meta charset="utf-8">
<style>

.slideshow-container {
	max-width: 500px;
	position:relative;
	margin: auto;
}

.prev, .next {
  cursor: pointer;
  position: absolute;
  top: 50%;
  width: auto;
  padding: 16px;
  margin-top: -22px;
  color: white;
  font-weight: bold;
  font-size: 18px;
  transition: 0.6s ease;
  border-radius: 0 3px 3px 0;
}

.next {
  right: 0;
  border-radius: 3px 0 0 3px;
}
.prev:hover, .next:hover {
  background-color: rgba(0,0,0,0.8);
}

.text {
  color: #f2f2f2;
  font-size: 15px;
  padding: 8px 12px;
  position: absolute;
  bottom: 8px;
  width: 100%;
  text-align: center;
}

.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}
.dot {
  cursor:pointer;
  height: 13px;
  width: 13px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.active, .dot:hover {
  background-color: #717171;
}
.fade {
  -webkit-animation-name: fade;
  -webkit-animation-duration: 1.5s;
  animation-name: fade;
  animation-duration: 1.5s;
}

@-webkit-keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}
@keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

@media only screen and (max-width: 300px) {
  .prev, .next,.text {font-size: 11px}
}
body {background-image: url("clinicbr.jpg");
			background-size: 100%;				;
		background-repeat:no-repeat;}
	
h1 {

	background-image: url(clinicbr.jpg);
	background-repeat: no-repeat;
	background-size: 100%;
	height: 300px; width: 650px; font-size: 3em;
	padding-left: none; padding-top:none;
	border: 1px solid #000033;
	border-radius: 50px

}

h2 { color: #000033; 
     font-family: arial, sans-serif;
	}
	

li {
    display: inline;
}
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}

li {
    float: left;
}

li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover {
    background-color: #111;
}

div.copyright{position: fixed;
    bottom: 0;
    width: 100%;}

</style>
</head>
<body>

<header>

	<center></center>
</h1></center>

</header>
<ul>
<li> <a href="index.php">Home</a></li>
 <li> <a href="login.php">Login</a></li>
 <li> <a href="contact1.php">Contact</a></li>
</ul>
<main>
<center><h2><b><big>Kwantlen Clinic</big></b></h2></center>

<br>
<br>






<center><h2>Where we come from</h2></center>
<center><p><strong>Kwantlen Clinic was made to provide health care nearby to students, and to local residents</strong></p><br><br></center>
<center><h2>Our Goal</h2>
	<p><strong>Our goal is to provide the best service and to have our doctors give the right treatments to our patients.
	<br><br></strong></p></center>
<center><h2>Location</h2>
	<p><strong>We are located in Surrey British Columbia at Kwantlen Polytechnic University</strong></p><br><br>
	</center>
	

	
	
</main>
<footer>
<br>
<br>
<br>
<br>
<br>
<center><div class="copyright">Copyright &copy; 2017 Kwantlen Clinic</div></center>
</footer>
</body>
</html>
